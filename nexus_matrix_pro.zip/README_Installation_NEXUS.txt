======================================================================
         INSTALLATION GUIDE - NEXUS MATRIX PLATINUM
======================================================================

Welcome to the NEXUS MATRIX automatic operating system.

Carefully follow these 4 steps to correctly install the software 
on the MetaTrader 4 platform.

----------------------------------------------------------------------
STEP 1: OPEN THE METATRADER 4 SYSTEM folder
----------------------------------------------------------------------
To install the files you must use the platform's native secure path, 
without searching manually through Windows folders:

1. Open your MetaTrader 4 platform.
2. Click on the top menu File.
3. Select the option Open Data Folder.

- A window will automatically open on your desktop.
- Inside this window, find the folder named MQL4 and double-click 
  to enter it.

----------------------------------------------------------------------
STEP 2: PASTE THE SOFTWARE FILES (EXACT PLACEMENT)
----------------------------------------------------------------------
Insert the commercial package files exactly into their respective 
folders found inside MQL4:

1. THE ALGORITHM FILE (.ex4):
   - Take the file: NEXUS_MATRIX_SYSTEM_VX_X.ex4
   - Paste it into the folder: MQL4 \ Experts

2. THE LANGUAGE DICTIONARY FILES (.txt):
   - Take the language files: it_IT.txt, en_US.txt, etc.
   - Create a folder inside MQL4 \ Files named: Nexus_Languages
   - Paste all files into the folder: MQL4 \ Files \ Nexus_Languages

----------------------------------------------------------------------
STEP 3: ACTIVATION ON THE EURUSD M15 OPERATIONAL CHART
----------------------------------------------------------------------
1. Return to the MetaTrader 4 platform.
2. Go to the left panel called Navigator (if it is closed, you 
   can open it by pressing the Ctrl + N keys on your keyboard).
3. Right-click on the Expert Advisors option and click on Refresh.
4. Open a clean chart of the EURUSD currency.
5. Set the chart Timeframe strictly to M15.
6. Select the NEXUS_MATRIX_SYSTEM_VXX_XX robot from the navigator 
   list and drag it with the mouse onto the M15 chart.

----------------------------------------------------------------------
STEP 4: ACTIVATION DURATION
----------------------------------------------------------------------
1. After the first installation, the software will automatically 
   start in free TRIAL mode for 30 days. Subsequently, to continue 
   its use, it will be necessary to purchase at least one type of 
   commercial license.
2. To activate a commercial license, press (F7) and in the input 
   panel find the field called Activation Key.
3. Double-click in the field next to the label and paste your 
   customized alphanumeric license key (e.g., A-16723036) officially 
   provided by the support team.
4. Click on the OK button at the bottom to confirm.

----------------------------------------------------------------------
TIPS AND VERIFICATION FOR LIVE MODE RUNNING
----------------------------------------------------------------------
- Make sure that the AutoTrading button located at the top of the 
  main MetaTrader 4 toolbar is pressed and shines with a GREEN icon.

- The control Dashboard will turn on instantly on your Wide monitor, 
  displaying in operational Lime Green (or White), indicating the 
  telemetry of remaining subscription days and putting the strategic 
  baskets online ready to operate on the market.

======================================================================
Technical and Institutional Support: assistenza@trendfarm.it
======================================================================

